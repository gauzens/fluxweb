#' the new fancy package fluxweb that fluxes webs
#' @title The fluxweb package
#' @author Benoit Gauzens
#' @docType package
#' @name fluxweb-package
#' @import stats
NA
