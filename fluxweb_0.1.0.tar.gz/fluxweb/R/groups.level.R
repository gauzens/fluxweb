#'Aggregated version of the Food web of a soil network ecosystem and species general information (\code{species.level}).
#'
#'This dataset contains the matrix describing trophic interactions between trophic groups of a soil food-web (reference)
#'as well as some ecological information on these groups: biomasses, body masses and and species composition.
#'
#'@format a list of 5 elements:
#'\describe{
#'  \item{mat}{the network adjacency matrix}
#'  \item{biomasses}{groups total biomasses (g)}
#'  \item{bodymasses}{group mean bodyamasses of species (g)}
#'  \item{efficiencies}{group species mean assimilation efficiencies}
#'  \item{species.tgs}{groups' species composition}
#'}
#'
#'@name groups.level
NULL